
const express = require('express');
const router = express.Router();
const Service = require('../models/Service');

router.get('/', async (req, res) => {
    const services = await Service.find();
    res.json(services);
});

router.post('/add', async (req, res) => {
    const { title, description, price } = req.body;
    const newService = new Service({ title, description, price });
    await newService.save();
    res.status(201).send('Service Added');
});

module.exports = router;
