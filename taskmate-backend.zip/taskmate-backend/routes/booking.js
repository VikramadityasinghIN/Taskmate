
const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');

router.post('/', async (req, res) => {
    const { userId, serviceId, date } = req.body;
    const booking = new Booking({ userId, serviceId, date });
    await booking.save();
    res.status(201).send('Booking Created');
});

router.get('/:userId', async (req, res) => {
    const bookings = await Booking.find({ userId: req.params.userId }).populate('serviceId');
    res.json(bookings);
});

module.exports = router;
